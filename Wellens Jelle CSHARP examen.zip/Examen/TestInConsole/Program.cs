﻿using System;
using MachineFunctions;
    public static class mainTestDing
    {
        public static void Main(string[] args)
        {
            Machine x = new Machine();
            
        }
    }
